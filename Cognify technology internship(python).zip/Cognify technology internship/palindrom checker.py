def palindrom(word):
    return word ==word[::-1]
while True:
    user_input = input("enter the word:")
    if palindrom(user_input):
        print("this is a palindrom")
    else:
        print("this is a not a palindrom")
    break