import re
def validator(email):
    email_condition =r'^[a-zA-z0-9._%+-]+@[a-zA-z0-9.-]+\.[a-zA-Z]{2,}$'
    if re.match(email_condition,email):
        return "valid Email"
    else:
        return"invalid Email"
email = input("enter the Email address:")
print(validator(email))