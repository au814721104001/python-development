num_1 = float(input("enter the number:"))
num_2 = float(input("enter the number:"))
operator = input ("enter the operator('+','-','*','/','%'):")
if operator == '+':
    result = num_1 + num_2
    print(result)
elif operator == '-':
    result=num_1 - num_2
    print(result)
elif operator == '*':
    result=num_1 * num_2
    print(result)
elif operator == '/':
    result=num_1 /num_2
    print(result)
elif operator == '%':
    result=num_1 % num_2
    print(result)
else:
    print(f"{operator} please enter a valid operator")
          