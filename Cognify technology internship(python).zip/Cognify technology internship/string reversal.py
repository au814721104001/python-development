def reverse_string(str):
    return str[: :-1]
while True:
    str= input("enter the string:")
    reverse_str = reverse_string(str)
    print(reverse_str)
    break