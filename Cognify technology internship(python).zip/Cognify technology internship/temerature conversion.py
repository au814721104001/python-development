def celsius_to_fahrenheit(celsius):
    return(celsius * 9/5) + 32
def fahrenheit_to_celsius(fahrenheit):
    return(fahrenheit - 32)* 9/5
temperature = float (input("enter the temprature value:"))
unit = input("enter the unit of measurement ..('C' for celsius and 'F' for fahrenheit )C/F:").upper()
if unit == 'C':
    converted_temerature = celsius_to_fahrenheit(temperature)
    print(f"{temperature}°C is equal to {converted_temerature} °F")                               
elif unit == 'F':
    converted_temperature = fahrenheit_to_celsius(temperature)
    print(f"(temperature)°F is equal to {converted_temperature}°C")
else:
    print("invalid measurment unit please enter a 'C' for celsius and 'F'' for fahrenheit")